=== WordPress MpExtension Extension ===
Contributors: forwardcreation
Donate link: https://ko-fi.com/A8385C9
Requires at least: 3.0.1
Tested up to: 5.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A Boilerplate Extension for WPBookList that creates a menu page and has it's own tabs.

== Description ==

A Boilerplate Extension for WPBookList that creates a menu page and has it's own tabs.

== Installation ==

**Method** **1)** Simply drop this folder (unzipped) into your WordPress plugin directory (/wp-content/plugins).

**Method** **2)** In the WordPress admin dashboard, click on ‘Plugins’ on the left-hand side, click on ‘Add New’ towards the very top of the page, click on ‘Upload Plugin’, and upload the ‘wpbooklist-search.zip’ file you downloaded.

== Screenshots ==


== Frequently Asked Questions ==


== Changelog ==

**v1.0.0** - Initial Release of The WordPress MpExtension Extension. 

== Upgrade Notice ==

= 1.0.0 =
Initial Release of The WordPress MpExtension Extension.
